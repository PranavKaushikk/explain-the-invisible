/**
 * api.js — thin fetch wrapper for the Explain the Invisible backend.
 *
 * This is the only file that knows the backend's base URL.
 * Components and App.jsx never hard-code fetch() calls; they import
 * named functions from here.
 *
 * In v0.4 (AI integration) the server-side implementation of
 * fetchVisualization will change; this client module stays the same
 * because the response shape is contractually fixed.
 */

const BASE_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3000'

/**
 * Fetch a visualization dataset for the given topic from the backend.
 *
 * @param {string} topic — raw topic string (e.g. "HTTPS Handshake")
 * @returns {Promise<object>} the visualization object
 * @throws {Error} with a user-legible message on network or 404 errors
 */
export async function fetchVisualization(topic) {
  // Encode the topic for use in a URL path segment.
  // The server normalises hyphens and casing, but encodeURIComponent
  // is still needed to handle characters like spaces correctly.
  const slug = encodeURIComponent(topic.trim().toLowerCase())
  const url = `${BASE_URL}/api/visualization/${slug}`

  let response
  try {
    response = await fetch(url)
  } catch {
    throw new Error(
      'Could not reach the server. Make sure the backend is running on port 3000.'
    )
  }

  if (response.status === 404) {
    throw new Error(`No visualization found for "${topic}".`)
  }

  if (!response.ok) {
    throw new Error(`Server error (${response.status}). Please try again.`)
  }

  const body = await response.json()
  // The server wraps the visualization in { data: { ... } }
  return body.data
}
